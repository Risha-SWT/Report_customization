from django.apps import AppConfig


class CarboneAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carbone_app'
